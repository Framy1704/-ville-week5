#Week 5 – Unit Tests


1. npm install
2. npm test
